# Site physique-chimie — pages « parcours »

```
site/
├── index.html                      ← page d'accueil (existante, non fournie ici)
├── assets/
│   ├── css/parcours.css            ← style commun des pages chapitre
│   └── js/parcours.js              ← visionneuse + étapes cochées
├── gabarit/chapitre-modele.html    ← à copier pour chaque nouveau chapitre
├── 1ere-spe/
│   └── ch01-mole/index.html
└── 5eme/
    └── ch01-matiere/index.html
```

## Créer un chapitre
1. Copier `gabarit/chapitre-modele.html` dans `NIVEAU/chXX-nom/index.html`.
2. Sur `<body>`, poser `class="niveau-1spe|niveau-ens|niveau-5e"` et `data-page="identifiant-unique"`.
3. Remplacer chaque `ID_DRIVE` par l'identifiant du fichier partagé.

## Liens Drive
- Fichier (pdf, docx, odt, jpg, mp4) : `https://drive.google.com/file/d/ID/preview`
- Google Doc : `https://docs.google.com/document/d/ID/preview`
- Le dossier Drive doit être partagé en « Tous les utilisateurs disposant du lien ».
- Un fichier `.html` (ex. un calculateur) ne s'affiche pas via Drive : le déposer dans le dossier du chapitre et le lier en relatif.

## Couleurs des étapes (`style="--c:var(--…)"`)
green = TP · blue = documentaire · brown = lecture · red = entraînement · purple = atelier · olive = expert · ink = bilan

## Étapes cochées
Mémorisées dans le navigateur de l'élève (localStorage), clé `parcours:` + `data-page`.
Rien n'est envoyé nulle part ; le bouton « Tout décocher » remet à zéro.

## Hébergement GitHub Pages
Dépôt → Settings → Pages → Source : branche `main`, dossier `/` (root). Le site est servi à
`https://UTILISATEUR.github.io/DEPOT/`. Les chemins relatifs `../../assets/` fonctionnent tels quels.
